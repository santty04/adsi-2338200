<?php
    // Config Sessions
    session_start();

    // Config URL Site 
    $base_url = 'http://localhost:8000';
    $public   = $base_url . '/public';
    $config   = $base_url . '/config';
    $css      = $public . '/css';
    $js       = $public . '/js';

    // Config Data Base
    $host    = '127.0.0.1';
    $user    = 'root';
    $passwd  = '';
    $name_db = 'adsi2338200';


